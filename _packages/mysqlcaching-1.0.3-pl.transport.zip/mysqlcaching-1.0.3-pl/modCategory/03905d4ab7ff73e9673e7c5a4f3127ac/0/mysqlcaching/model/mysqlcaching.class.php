<?php
class mysqlcaching {}