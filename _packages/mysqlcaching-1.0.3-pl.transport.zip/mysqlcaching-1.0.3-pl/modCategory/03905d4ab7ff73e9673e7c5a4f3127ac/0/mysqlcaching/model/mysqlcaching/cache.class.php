<?php
/**
 * @package mysqlcache
 */
class Cache extends xPDOObject {}