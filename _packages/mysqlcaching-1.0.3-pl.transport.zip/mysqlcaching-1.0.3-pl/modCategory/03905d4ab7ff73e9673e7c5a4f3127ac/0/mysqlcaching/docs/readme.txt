--------------------
mysqlcaching
--------------------
Version: 1.0.0
Maintainer: Mark Willis <mark.willis@adi.do>
--------------------

Mysql Caching is a database backed alternative to File / APC / Memcache based caching